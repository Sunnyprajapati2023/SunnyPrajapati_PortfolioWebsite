document.addEventListener("DOMContentLoaded", () => {
  // Animate skill bars
  const progresses = document.querySelectorAll(".progress");
  const animateProgress = () => {
    progresses.forEach(p => {
      const rect = p.getBoundingClientRect();
      if (rect.top < window.innerHeight - 40) {
        p.style.width = p.dataset.progress + "%";
      }
    });
  };
  window.addEventListener("scroll", animateProgress);
  animateProgress();

  // Contact Form
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", e => {
      e.preventDefault();
      alert("Thank you for your message!");
      contactForm.reset();
    });
  }
});
